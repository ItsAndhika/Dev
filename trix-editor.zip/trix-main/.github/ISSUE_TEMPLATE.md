Describe the bug or issue here…

##### Steps to Reproduce

1. 
2. 
3. 

##### Details

* Trix version: 
* Browser name and version:
* Operating system: 
